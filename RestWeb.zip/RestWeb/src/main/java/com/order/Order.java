package com.order;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatTypes;


// apache tomcat 9

public class Order { //Entity / pojo / Java BEAN / component  
	
	private int 	orderId; // primary key 
	
	// "orderDate" : "2011-11-26T15:45:6.000"
	//@DateTimeFormat
	//@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-mm-dd")
	
	//@DateTimeFormat(iso = DateTimeFormat.ISO.TIME)
	/*class LocalDateDeserializer extends StdDeserializer<LocalDate> {

	    private static final long serialVersionUID = 1L;

	    protected LocalDateDeserializer() {
	        super(LocalDate.class);
	    }


	    @Override
	    public LocalDate deserialize(JsonParser jp, DeserializationContext ctxt)
	            throws IOException, JsonProcessingException {
	        return LocalDate.parse(jp.readValueAs(String.class));
	    }

	}
	
	public class LocalDateSerializer extends StdSerializer<LocalDate> {

	    private static final long serialVersionUID = 1L;

	    public LocalDateSerializer(){
	        super(LocalDate.class);
	    }

	    @Override
	    public void serialize(LocalDate value, JsonGenerator gen, SerializerProvider sp) throws IOException, JsonProcessingException {
	        gen.writeString(value.format(DateTimeFormatter.ISO_LOCAL_DATE));
	    }
	}
	
	@JsonDeserialize(using = LocalDateDeserializer.class)  
	@JsonSerialize(using = LocalDateSerializer.class)  
	*/
	
	
	LocalDateTime 	orderDate; //?
	private int 	tableNumber; // ?
	private String 	foodItem; //customer
	private float 	price;    //restaurant
	private int  	quantity;  //customer
	private float 	total;   //restaurant
	
	
	/*public Order(int orderId, LocalDateTime orderDate, int tableNumber, String foodItem, float price, int quantity) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.tableNumber = tableNumber;
		this.foodItem = foodItem;
		this.price = price;
		this.quantity = quantity;
		this.total = this.quantity * this.price; //autocalculate
	}*/
	
	public Order(int orderId, int tableNumber, String foodItem, float price, int quantity) {
		super();
		System.out.println("Order(without date)");
		this.orderId = orderId;
		this.orderDate = LocalDateTime.now();
		this.tableNumber = tableNumber;
		this.foodItem = foodItem;
		this.price = price;
		this.quantity = quantity;
		this.total = this.quantity * this.price; //autocalculate
	}
	
	public Order() {
		System.out.println("Order()..setting a defaul date..");
		this.orderDate = LocalDateTime.now();
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
		System.out.println("setOrderId()");
	}
	
	public LocalDateTime getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(LocalDateTime orderDate) {
		this.orderDate = orderDate;
		System.out.println("setOrderDate()");
	}
	
	public int getTableNumber() {
		return tableNumber;
	}
	
	public void setTableNumber(int tableNumber) {
		this.tableNumber = tableNumber;
		System.out.println("setTableNumber()");
	}
	
	public String getFoodItem() {
		return foodItem;
	}
	public void setFoodItem(String foodItem) {
		this.foodItem = foodItem;
		System.out.println("setFoodItem()");
	}
	
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
		System.out.println("setPrice()");
	}
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
		System.out.println("setQuantity()");
		this.total =getPrice() * getQuantity();
		
	}
	
	public float getTotal() {
		return total;
	}
	public void setTotal(float total) {
		
		System.out.println("setTotal()");
	}
	
	
	
}
