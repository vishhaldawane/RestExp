package com.order;

import java.sql.DriverManager;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


public class OrderRepositoryImpl2 implements OrderRepository {
	
	static List<Order> orderList = new ArrayList<Order>(); // DATA
	
	static  { //INITIALIZER run only once 
		
		//LOAD THE DATABASE DRIVER AND WILL CONNECT TO DB
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		
		
	}
	
	
	@Override
	public void createOrder(Order order) {  // CREATE REPO
		System.out.println("Adding the order....");
		orderList.add(order);
	}

	@Override
	public Order selectOrder(int orderId) { // SELECT SINGLE REPO
		System.out.println("Searching the order...."+orderId);
		
		Order foundOrder = null;
		
		for(Order theOrder : orderList) {
			if(theOrder.getOrderId() == orderId) {
				foundOrder = theOrder;
				break;
			}
		}
		return foundOrder;
	}

	@Override
	public List<Order> selectAllOrders() { //SELECT ALL
		System.out.println("Selecting all orders....");
		return orderList;
	}

	@Override
	public void updateOrder(Order order) { //UPDATE
		System.out.println("Updating the order...");
		
		for(int i=0;i<orderList.size();i++) {
			Order tempOrder = orderList.get(i);
			if(tempOrder.getOrderId() == order.getOrderId())
			{
				orderList.remove(i);
				orderList.add(order);
				break;
			}
		}

	}

	@Override
	public void deleteOrder(int orderId) { //DELETE
		System.out.println("Deleting order....");
		for(int i=0;i<orderList.size();i++) {
			Order tempOrder = orderList.get(i);
			if(tempOrder.getOrderId() == orderId)
			{
				orderList.remove(i);
				break;
			}
		}

	}

}
