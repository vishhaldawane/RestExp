/**
 * 
 */

function alertMe() {
			alert("Hello to java script1");
			
			var theSource = document.getElementById("source").value;
			var theTarget = document.getElementById("target").value;
			alert(theSource);
			alert(theTarget);
			
			if(theSource == theTarget) {
				alert("Target cannot be the same as of the Source");
				document.getElementById("targetmsg").innerHTML='Source and Target cannot be the same';
				return false;
				
			}
			else {
				alert("Searching the flights....");
				
			}
			return true;
		}
	