package com.order;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

// http://localhost:8080/RestWeb/rest/order/greet

@Path("/order")
public class OrderService {

	//OrderRepositoryImpl orderRepo = new OrderRepositoryImpl(); //ArrayList
	OrderRepositoryImpl2 orderRepo = new OrderRepositoryImpl2(); // CRUD
	
	public OrderService() {
		System.out.println("==========> OrderService()....");
	}
	// @GET   @POST   @PUT    @DELETE
	
//	http://localhost:8080/RestWeb/rest/order/getOrders	
	@GET
	@Path("/getOrders") // 
	@Produces(MediaType.APPLICATION_JSON)
	public List<Order> getAllOrders() {
		System.out.println("getAllOrders() <-- /getOrders");
		return orderRepo.selectAllOrders();
	}
	//												 {oid}
//	http://localhost:8080/RestWeb/rest/order/getOrder/102	
	@GET
	@Path("/getOrder/{oid}") // 
	@Produces(MediaType.APPLICATION_JSON)
	public Order getTheOrder(@PathParam("oid") int orderId) {
		System.out.println("getAllOrders() <-- /getOrders");
		return orderRepo.selectOrder(orderId);
	}
	
	
	@DELETE
	@Path("/deleteOrder/{oid}") // 
	@Produces(MediaType.APPLICATION_JSON)
	public void deleteTheOrder(@PathParam("oid") int orderId) {
		System.out.println("deleteTheOrder() <-- /getOrders");
		orderRepo.deleteOrder(orderId);
	}
	
	@POST
	@Path("/addOrder") // 
	@Produces(MediaType.APPLICATION_JSON)
	public void addTheOrder(Order newOrder) {
		System.out.println("addTheOrder() <-- /addOrder");
		orderRepo.createOrder(newOrder);
	}
	
	@PUT
	@Path("/updateOrder") // 
	@Produces(MediaType.APPLICATION_JSON)
	public void modifyTheOrder(Order updatedOrder) {
		System.out.println("addTheOrder() <-- /addOrder : "+updatedOrder.getOrderId());
		orderRepo.updateOrder(updatedOrder);
	}
	
	
	
	
	@GET
	@Path("/greet1")
	//@Produces(MediaType.APPLICATION_JSON)
	public String greetings1() {
		return "Welcome to OrderService1";
	} 
	
	@GET
	@Path("/greet2")
	//@Produces(MediaType.APPLICATION_JSON)
	public String greetings2() {
		return "Welcome to OrderService2";
	}
	
	

}

/*
	various jars
	
	Pickle   Salt    Sugar    Maida   .. .. ...
	label	 label	 label	  label
	
	electric switches
	
	F    T   
	
	
	Annotation - extra information
			- extended version of comments
			
	
	Comments - 



*/