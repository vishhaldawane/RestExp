package com.order;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.xml.bind.annotation.adapters.XmlAdapter;

				/*6											7*/			
public class TimeStampAdapter extends XmlAdapter<String, Timestamp> {
    @Override //8
    public Timestamp unmarshal(String s) throws Exception {
        System.out.println("unmarshal...");// string into date
    	return Timestamp.valueOf(s); //9 // while adding Order - '2021-11-28T11:30:9:987'
    	//Timestamp.
    }
    @Override				//10
    public String marshal(Timestamp dateTime) throws Exception {
    	 System.out.println("marshal..."); //date unto string 
    	return dateTime.toString();
    }   
}