package com.order;

import java.util.List;


public interface OrderRepository {
	//here we will have 5 methods for REST
	
	void createOrder(Order order); //declaration
	Order selectOrder(int orderid);
	List<Order> selectAllOrders();
	void updateOrder(Order order);
	void deleteOrder(int orderId);
	
}
