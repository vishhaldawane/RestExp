package com.order;
import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonFormatTypes;


// apache tomcat 9

public class Order { //Entity / pojo / Java BEAN / component  
	
	private int 	orderId; // primary key 
	Timestamp 		orderDate; //1
	private int 	tableNumber; // ?
	private String 	foodItem; //customer
	private float 	price;    //restaurant
	private int  	quantity;  //customer
	private float 	total;   //restaurant
	
												//2
	public Order(int orderId,int tableNumber, Timestamp orderDate, String foodItem, float price, int quantity) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.tableNumber = tableNumber;
		this.foodItem = foodItem;
		this.price = price;
		this.quantity = quantity;
		this.total = this.quantity * this.price; //autocalculate
	}
	
	
	public Order() {
		System.out.println("Order()..setting a default date..");
		//this.orderDate = LocalDateTime.now();
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
		System.out.println("setOrderId()");
	}
	
	@XmlJavaTypeAdapter(TimeStampAdapter.class)//3
	public Timestamp /*4*/ getOrderDate() {
		System.out.println("==>TimeStampAdapter:getOrderDate()...."+orderDate);
		return orderDate;
	}
	public void setOrderDate(Timestamp/*5*/ orderDate) {
		this.orderDate = orderDate;
		System.out.println("==>TimeStampAdapter:setOrderDate()..."+orderDate);
	}
	
	public int getTableNumber() {
		return tableNumber;
	}
	
	public void setTableNumber(int tableNumber) {
		this.tableNumber = tableNumber;
		System.out.println("setTableNumber()");
	}
	
	public String getFoodItem() {
		return foodItem;
	}
	public void setFoodItem(String foodItem) {
		this.foodItem = foodItem;
		System.out.println("setFoodItem()");
	}
	
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
		System.out.println("setPrice()");
	}
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
		System.out.println("setQuantity()");
		this.total =getPrice() * getQuantity();
		
	}
	
	public float getTotal() {
		return total;
	}
	public void setTotal(float total) {
		
		System.out.println("setTotal()");
	}
	
	
	
}
